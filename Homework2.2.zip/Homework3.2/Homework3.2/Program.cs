﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers;
            int sum = 0;

            numbers = new int[] { 1, 5, 10, 30 };


            for (int i = 0; i < numbers.Length; i++)
            {
                sum += numbers[i];
                Console.WriteLine(numbers[i]);
            }
            Console.WriteLine("sum = " + sum);

            Console.ReadLine();
        }
    }
}
