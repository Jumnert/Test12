﻿namespace Home_work_4_AJ
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabLength = new System.Windows.Forms.Label();
            this.LabWidth = new System.Windows.Forms.Label();
            this.LabRectangleArea = new System.Windows.Forms.Label();
            this.TxtLength = new System.Windows.Forms.TextBox();
            this.TxtWidth = new System.Windows.Forms.TextBox();
            this.TxtRectangleArea = new System.Windows.Forms.TextBox();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnArea = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // LabLength
            // 
            this.LabLength.AutoSize = true;
            this.LabLength.Font = new System.Drawing.Font("Noto Serif SC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabLength.Location = new System.Drawing.Point(12, 421);
            this.LabLength.Name = "LabLength";
            this.LabLength.Size = new System.Drawing.Size(85, 29);
            this.LabLength.TabIndex = 1;
            this.LabLength.Text = "Length";
            // 
            // LabWidth
            // 
            this.LabWidth.AutoSize = true;
            this.LabWidth.Font = new System.Drawing.Font("Noto Serif SC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabWidth.Location = new System.Drawing.Point(12, 492);
            this.LabWidth.Name = "LabWidth";
            this.LabWidth.Size = new System.Drawing.Size(77, 29);
            this.LabWidth.TabIndex = 2;
            this.LabWidth.Text = "Width";
            // 
            // LabRectangleArea
            // 
            this.LabRectangleArea.AutoSize = true;
            this.LabRectangleArea.Font = new System.Drawing.Font("Noto Serif SC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabRectangleArea.Location = new System.Drawing.Point(12, 555);
            this.LabRectangleArea.Name = "LabRectangleArea";
            this.LabRectangleArea.Size = new System.Drawing.Size(167, 29);
            this.LabRectangleArea.TabIndex = 3;
            this.LabRectangleArea.Text = "Rectangle Area";
            // 
            // TxtLength
            // 
            this.TxtLength.Location = new System.Drawing.Point(380, 421);
            this.TxtLength.Name = "TxtLength";
            this.TxtLength.Size = new System.Drawing.Size(512, 26);
            this.TxtLength.TabIndex = 4;
            this.TxtLength.TextChanged += new System.EventHandler(this.TexLength_TextChanged);
            // 
            // TxtWidth
            // 
            this.TxtWidth.Location = new System.Drawing.Point(380, 492);
            this.TxtWidth.Name = "TxtWidth";
            this.TxtWidth.Size = new System.Drawing.Size(512, 26);
            this.TxtWidth.TabIndex = 5;
            // 
            // TxtRectangleArea
            // 
            this.TxtRectangleArea.Location = new System.Drawing.Point(380, 555);
            this.TxtRectangleArea.Name = "TxtRectangleArea";
            this.TxtRectangleArea.Size = new System.Drawing.Size(512, 26);
            this.TxtRectangleArea.TabIndex = 6;
            // 
            // BtnClear
            // 
            this.BtnClear.Font = new System.Drawing.Font("Noto Serif SC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClear.Image = global::Home_work_4_AJ.Properties.Resources.clear_symbol_24px;
            this.BtnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClear.Location = new System.Drawing.Point(493, 646);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(183, 77);
            this.BtnClear.TabIndex = 8;
            this.BtnClear.Text = "Clear";
            this.BtnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnArea
            // 
            this.BtnArea.Font = new System.Drawing.Font("Noto Serif SC", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnArea.Image = global::Home_work_4_AJ.Properties.Resources.layers_30px;
            this.BtnArea.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnArea.Location = new System.Drawing.Point(144, 646);
            this.BtnArea.Name = "BtnArea";
            this.BtnArea.Size = new System.Drawing.Size(183, 77);
            this.BtnArea.TabIndex = 7;
            this.BtnArea.Text = "Area";
            this.BtnArea.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnArea.UseVisualStyleBackColor = true;
            this.BtnArea.Click += new System.EventHandler(this.BtnArea_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Home_work_4_AJ.Properties.Resources.download__5_;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(991, 362);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 753);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnArea);
            this.Controls.Add(this.TxtRectangleArea);
            this.Controls.Add(this.TxtWidth);
            this.Controls.Add(this.TxtLength);
            this.Controls.Add(this.LabRectangleArea);
            this.Controls.Add(this.LabWidth);
            this.Controls.Add(this.LabLength);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label LabLength;
        private System.Windows.Forms.Label LabWidth;
        private System.Windows.Forms.Label LabRectangleArea;
        private System.Windows.Forms.TextBox TxtLength;
        private System.Windows.Forms.TextBox TxtWidth;
        private System.Windows.Forms.TextBox TxtRectangleArea;
        private System.Windows.Forms.Button BtnArea;
        private System.Windows.Forms.Button BtnClear;
    }
}