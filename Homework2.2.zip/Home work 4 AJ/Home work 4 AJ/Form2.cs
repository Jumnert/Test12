﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Home_work_4_AJ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void TexLength_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtLength.Clear();
            TxtWidth.Clear();
            TxtRectangleArea.Clear();
        }

        private void BtnArea_Click(object sender, EventArgs e)
        {
            float total;
            float length = float.Parse(TxtLength.Text);
            float width = float.Parse(TxtWidth.Text);

            total = length * width;

            TxtRectangleArea.Text = $"{total}m2";
        }
    }
}
