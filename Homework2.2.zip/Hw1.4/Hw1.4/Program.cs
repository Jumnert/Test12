﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hw1._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter quantity of product=");
            int qty = int.Parse(Console.ReadLine());
            Console.Write("enter unit price=");
            double price = double.Parse(Console.ReadLine());
            double total = qty * price;
            Console.WriteLine("total=" + total + "$");
            int dis = 0;
            if (qty == 1)
            {

                dis = 5;

            }
            else if (qty == 2)
            {
                dis = 10;

            }
            else if (qty == 3)
            {
                dis = 15;


            }
            else
            {
                dis = 20;

            }
            Console.WriteLine("discount" + dis + "%");
            double subtotal = total - (total * dis) / 100;
            Console.WriteLine($"subtotal=" + subtotal + "$");

        }
    }
}
