﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hw1._3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first number:");
            double num1 = double.Parse(Console.ReadLine());

            Console.Write("enter the operator(* / + -):");
            char op = char.Parse(Console.ReadLine());
            Console.Write("enter the Second number:");
            double num2 = double.Parse(Console.ReadLine());
            double result;
            switch (op)
            {
                case '+':
                    result = num1 + num2;
                    Console.WriteLine("sum=" + result);
                    break;
                case '-':
                    result = num1 - num2;
                    Console.WriteLine("Sub=" + result);
                    break;
                case '/':
                    result = num1 / num2;
                    Console.WriteLine("result after division= " + result);
                    break;
                case '*':
                    result = num1 * num2;
                    Console.WriteLine("result after multiply=" + result);
                    break;
            }
        }
    }
    }
