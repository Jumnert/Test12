﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework3._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers;

            numbers = new int[] { 1, 5, 10, 30 };

            Console.WriteLine(numbers[0]);
            Console.WriteLine(numbers[1]);
            Console.WriteLine(numbers[2]);
            Console.WriteLine(numbers[3]);

            Console.ReadLine();
        }
    }
}
