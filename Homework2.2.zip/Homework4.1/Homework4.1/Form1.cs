﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework4._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnFahreheit_Click(object sender, EventArgs e)
        {
            //Declare
            double celsius = 0;
            double fahrenheit = 0;
            //Input
            celsius = Convert.ToDouble(TxtCelsius.Text);
            //Process
            fahrenheit = (celsius * 9 / 5) + 32;
            //Output
            TxtFahrenheit.Text = fahrenheit.ToString("F1");
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtCelsius.Text = "";
            TxtFahrenheit.Text = "";
        }

        private void BtnCelsius_Click(object sender, EventArgs e)
        {
            //Declare
            double celsius = 0;
            double fahrenheit = 0;
            //Input
            fahrenheit = Convert.ToDouble(TxtFahrenheit.Text);
            //Process
            celsius = (fahrenheit - 32) * 5 / 9;
            //Output
            TxtCelsius.Text = celsius.ToString("F1");
        }
    }
}
