﻿namespace Homework4._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtCelsius = new System.Windows.Forms.TextBox();
            this.TxtFahrenheit = new System.Windows.Forms.TextBox();
            this.BtnFahreheit = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnCelsius = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Homework4._1.Properties.Resources.photo_2025_06_27_10_24_13;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(959, 369);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 407);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Celsius";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(486, 407);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Fahrenheit";
            // 
            // TxtCelsius
            // 
            this.TxtCelsius.Location = new System.Drawing.Point(12, 462);
            this.TxtCelsius.Name = "TxtCelsius";
            this.TxtCelsius.Size = new System.Drawing.Size(327, 26);
            this.TxtCelsius.TabIndex = 3;
            // 
            // TxtFahrenheit
            // 
            this.TxtFahrenheit.Location = new System.Drawing.Point(490, 462);
            this.TxtFahrenheit.Name = "TxtFahrenheit";
            this.TxtFahrenheit.Size = new System.Drawing.Size(327, 26);
            this.TxtFahrenheit.TabIndex = 4;
            // 
            // BtnFahreheit
            // 
            this.BtnFahreheit.Location = new System.Drawing.Point(16, 556);
            this.BtnFahreheit.Name = "BtnFahreheit";
            this.BtnFahreheit.Size = new System.Drawing.Size(218, 62);
            this.BtnFahreheit.TabIndex = 5;
            this.BtnFahreheit.Text = "Fahreheit";
            this.BtnFahreheit.UseVisualStyleBackColor = true;
            this.BtnFahreheit.Click += new System.EventHandler(this.BtnFahreheit_Click);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(318, 556);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(218, 62);
            this.BtnClear.TabIndex = 6;
            this.BtnClear.Text = "Clear";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnCelsius
            // 
            this.BtnCelsius.Location = new System.Drawing.Point(609, 556);
            this.BtnCelsius.Name = "BtnCelsius";
            this.BtnCelsius.Size = new System.Drawing.Size(218, 62);
            this.BtnCelsius.TabIndex = 7;
            this.BtnCelsius.Text = "Celsius";
            this.BtnCelsius.UseVisualStyleBackColor = true;
            this.BtnCelsius.Click += new System.EventHandler(this.BtnCelsius_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(962, 674);
            this.Controls.Add(this.BtnCelsius);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnFahreheit);
            this.Controls.Add(this.TxtFahrenheit);
            this.Controls.Add(this.TxtCelsius);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtCelsius;
        private System.Windows.Forms.TextBox TxtFahrenheit;
        private System.Windows.Forms.Button BtnFahreheit;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnCelsius;
    }
}

