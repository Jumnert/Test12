﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Homework4._1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtUserName.Clear();
            TxtPassword.Clear();
            TxtConfirmPassword.Clear();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            // Declare
            string Confirmed, Password, UserName;

            // Input
            UserName = TxtUserName.Text;
            Password = TxtPassword.Text;
            Confirmed = TxtConfirmPassword.Text;

            // Process
            if (TxtUserName.Text == "" || TxtPassword.Text == "" ||  TxtConfirmPassword.Text == "")
    {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (TxtPassword.Text != TxtConfirmPassword.Text)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            if (TxtUserName.Text == "jee" && TxtPassword.Text == "123")
            {
                MessageBox.Show("Login successful!");

            }
            else
            {
                MessageBox.Show("Invalid login.");
            }
        }

        private void TxtUserName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
