﻿namespace Homework8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtInvoiceNo = new System.Windows.Forms.TextBox();
            this.TxtEmpName = new System.Windows.Forms.TextBox();
            this.TxtSex = new System.Windows.Forms.TextBox();
            this.TxtTotalHours = new System.Windows.Forms.TextBox();
            this.TxtHourlyRate = new System.Windows.Forms.TextBox();
            this.TxtTotalAmount = new System.Windows.Forms.TextBox();
            this.BtnCount = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnClose = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.BtnTotal = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 382);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "InvoiceNo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "EmpName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 460);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 26);
            this.label3.TabIndex = 3;
            this.label3.Text = "Sex";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 499);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 26);
            this.label4.TabIndex = 4;
            this.label4.Text = "Total Hours";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 540);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "Hourly Rate";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 579);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 26);
            this.label6.TabIndex = 6;
            this.label6.Text = "Total Amount";
            // 
            // TxtInvoiceNo
            // 
            this.TxtInvoiceNo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtInvoiceNo.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtInvoiceNo.Location = new System.Drawing.Point(191, 375);
            this.TxtInvoiceNo.Name = "TxtInvoiceNo";
            this.TxtInvoiceNo.Size = new System.Drawing.Size(440, 33);
            this.TxtInvoiceNo.TabIndex = 7;
            // 
            // TxtEmpName
            // 
            this.TxtEmpName.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtEmpName.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtEmpName.Location = new System.Drawing.Point(191, 414);
            this.TxtEmpName.Name = "TxtEmpName";
            this.TxtEmpName.Size = new System.Drawing.Size(440, 33);
            this.TxtEmpName.TabIndex = 8;
            // 
            // TxtSex
            // 
            this.TxtSex.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtSex.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSex.Location = new System.Drawing.Point(191, 453);
            this.TxtSex.Name = "TxtSex";
            this.TxtSex.Size = new System.Drawing.Size(440, 33);
            this.TxtSex.TabIndex = 9;
            // 
            // TxtTotalHours
            // 
            this.TxtTotalHours.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtTotalHours.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTotalHours.Location = new System.Drawing.Point(191, 492);
            this.TxtTotalHours.Name = "TxtTotalHours";
            this.TxtTotalHours.Size = new System.Drawing.Size(440, 33);
            this.TxtTotalHours.TabIndex = 10;
            // 
            // TxtHourlyRate
            // 
            this.TxtHourlyRate.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtHourlyRate.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtHourlyRate.Location = new System.Drawing.Point(191, 533);
            this.TxtHourlyRate.Name = "TxtHourlyRate";
            this.TxtHourlyRate.Size = new System.Drawing.Size(440, 33);
            this.TxtHourlyRate.TabIndex = 11;
            // 
            // TxtTotalAmount
            // 
            this.TxtTotalAmount.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.TxtTotalAmount.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTotalAmount.Location = new System.Drawing.Point(191, 572);
            this.TxtTotalAmount.Name = "TxtTotalAmount";
            this.TxtTotalAmount.Size = new System.Drawing.Size(440, 33);
            this.TxtTotalAmount.TabIndex = 12;
            // 
            // BtnCount
            // 
            this.BtnCount.FlatAppearance.BorderSize = 0;
            this.BtnCount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCount.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCount.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCount.Location = new System.Drawing.Point(12, 694);
            this.BtnCount.Name = "BtnCount";
            this.BtnCount.Size = new System.Drawing.Size(140, 55);
            this.BtnCount.TabIndex = 14;
            this.BtnCount.Text = "Count";
            this.BtnCount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnCount.UseVisualStyleBackColor = true;
            // 
            // BtnClear
            // 
            this.BtnClear.FlatAppearance.BorderSize = 0;
            this.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClear.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClear.Location = new System.Drawing.Point(12, 755);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(140, 55);
            this.BtnClear.TabIndex = 15;
            this.BtnClear.Text = "Clear";
            this.BtnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnClear.UseVisualStyleBackColor = true;
            // 
            // BtnClose
            // 
            this.BtnClose.FlatAppearance.BorderSize = 0;
            this.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClose.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnClose.Location = new System.Drawing.Point(12, 816);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(140, 55);
            this.BtnClose.TabIndex = 16;
            this.BtnClose.Text = "Close";
            this.BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBox1.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 26;
            this.listBox1.Location = new System.Drawing.Point(218, 627);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(413, 290);
            this.listBox1.TabIndex = 17;
            // 
            // BtnTotal
            // 
            this.BtnTotal.FlatAppearance.BorderSize = 0;
            this.BtnTotal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnTotal.Font = new System.Drawing.Font("Noto Serif SC", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTotal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnTotal.Location = new System.Drawing.Point(12, 636);
            this.BtnTotal.Name = "BtnTotal";
            this.BtnTotal.Size = new System.Drawing.Size(140, 55);
            this.BtnTotal.TabIndex = 13;
            this.BtnTotal.Text = "Total";
            this.BtnTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnTotal.UseVisualStyleBackColor = true;
            this.BtnTotal.Click += new System.EventHandler(this.BtnTotal_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Homework8.Properties.Resources.AdobeStock_508961803_scaled;
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(898, 347);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(898, 947);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.BtnClose);
            this.Controls.Add(this.BtnClear);
            this.Controls.Add(this.BtnCount);
            this.Controls.Add(this.BtnTotal);
            this.Controls.Add(this.TxtTotalAmount);
            this.Controls.Add(this.TxtHourlyRate);
            this.Controls.Add(this.TxtTotalHours);
            this.Controls.Add(this.TxtSex);
            this.Controls.Add(this.TxtEmpName);
            this.Controls.Add(this.TxtInvoiceNo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtInvoiceNo;
        private System.Windows.Forms.TextBox TxtEmpName;
        private System.Windows.Forms.TextBox TxtSex;
        private System.Windows.Forms.TextBox TxtTotalHours;
        private System.Windows.Forms.TextBox TxtHourlyRate;
        private System.Windows.Forms.TextBox TxtTotalAmount;
        private System.Windows.Forms.Button BtnTotal;
        private System.Windows.Forms.Button BtnCount;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.ListBox listBox1;
    }
}

