﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int month, day = 0;
            Console.Write("Enter a month: ");
            month = int.Parse(Console.ReadLine());
            switch (month) 
            {
                case 1: case 3: case 5: case 7: case 9: case 11:
                    day = 31; break;
                case 2:
                    day = 28; break;
                case 4: case 6: case 8: case 10: case 12:
                    day = 30; break;
                default:
                    day = 0; break;

            }
            Console.WriteLine("Mon\tTue\tWed\tThu\tFri\tSat\tSun");
            for (int i = 1; i <= day; i++)
            {
                if (i % 7 == 0)
                    Console.Write(i + "\n");
                else
                    Console.Write(i + "\t");
            }
            Console.ReadKey();

        }
    }
}
